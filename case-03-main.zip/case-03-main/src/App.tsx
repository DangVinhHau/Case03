import "./App.css";
import HomePage from "./App/component/homepage/HomePage";

function App() {
	return (
		<>
			<HomePage />
		</>
	);
}

export default App;
